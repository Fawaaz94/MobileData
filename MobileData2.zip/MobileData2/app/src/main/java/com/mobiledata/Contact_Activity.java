package com.mobiledata;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Contact_Activity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_);

        //BUTTONS

        Button call135 = (Button)this.findViewById(R.id.call135);
        call135.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + "135"));{
                    startActivity(intent);
                }
            }
        });

        Button call084135 = (Button)this.findViewById(R.id.call084135);
        call084135.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + "084135"));{
                    startActivity(intent);
                }
            }
        });


        // END OF BUTTONS

    }
}
