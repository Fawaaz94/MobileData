package com.mobiledata;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;

public class Vodacom extends Activity {

    private String inputText = "";
    private  EditText eText;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vodacom);

        //Set Screen Orientation to be locked on Portrait
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);


        eText = (EditText)findViewById(R.id.voucherNumberEditText);

        // BUTTONS

        Button b1 = (Button)this.findViewById(R.id.btnCheckAir);
        b1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse(Uri.parse("tel:" + "*100") + Uri.encode("#")));{
                    startActivity(intent);
                }
            }
        });

        Button b3 = (Button)this.findViewById(R.id.btnGO);
        b3.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                inputText = eText.getEditableText().toString();
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse(Uri.parse("tel:" + "*141*" +inputText) + Uri.encode("#")));{
                    startActivity(intent);
                }


            }
        });

        // END OF BUTTONS
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater vodacomMenuInflater = getMenuInflater();
        vodacomMenuInflater.inflate(R.menu.vodacom_menu, menu);

        return true;
    }

}
