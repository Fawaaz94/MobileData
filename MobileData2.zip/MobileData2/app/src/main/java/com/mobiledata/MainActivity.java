package com.mobiledata;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.os.Bundle;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;


public class MainActivity extends AppCompatActivity {

    private String inputText = "";
    private  EditText eText;


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);

        //Set Screen Orientation to be locked on Portrait
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);

       eText = (EditText)findViewById(R.id.voucherNumberEditText);

        // BUTTONS

        Button b1 = (Button)this.findViewById(R.id.btnCheckAir);
        b1.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse(Uri.parse("tel:" + "*101") + Uri.encode("#")));{
                    startActivity(intent);
                }
            }
        });


        Button b2 = (Button)this.findViewById(R.id.btnEmergency);
        b2.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse(Uri.parse("tel:" + "*147*7") + Uri.encode("#")));{
                    startActivity(intent);
                }
            }
        });


        Button b3 = (Button)this.findViewById(R.id.btnGO);
        b3.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                inputText = eText.getEditableText().toString();
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse(Uri.parse("tel:" + "*102*" +inputText) + Uri.encode("#")));{
                startActivity(intent);
                }


            }
        });


        Button b4 = (Button)this.findViewById(R.id.btnData);
        b4.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){

                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse(Uri.parse("tel:" + "*147") + Uri.encode("#")));{
                    startActivity(intent);
                }

            }
        });

        // END OF BUTTONS
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater mMenuInflater = getMenuInflater();
        mMenuInflater.inflate(R.menu.my_menu, menu);

        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.action_contact){

            Intent contactPageOpener = new Intent(MainActivity.this, Contact_Activity.class);
            startActivity(contactPageOpener);
        }

        if(item.getItemId() == R.id.action_vodacom){

            Intent vodacomPageOpener = new Intent(MainActivity.this, Vodacom.class);
            startActivity(vodacomPageOpener);
        }

        if(item.getItemId() == R.id.action_MTN){

            Intent mtnPageOpener = new Intent(MainActivity.this, MTN.class);
            startActivity(mtnPageOpener);
        }

        return super.onOptionsItemSelected(item);
    }

}
